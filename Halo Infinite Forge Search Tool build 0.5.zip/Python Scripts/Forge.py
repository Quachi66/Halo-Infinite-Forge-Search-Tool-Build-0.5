from colorama import * 
from fuzzywuzzy import fuzz
from Forge_Menu_Items import *

init(convert=True)

print("                                                                                                                                                             Made by Quinn Barron")


print("\nThis program prompts you for an item to search for. It will then return to you, in alphabetical order and numbered accordigly,")
print("every item in the Halo Infinite Forge Menu that contains a word matching your searched word")
print("The program will print out every item relevant to your search in a colour coded sequence along with a percentage next to it telling you how accurately")
print("a word in the item name matched the word you searched for. At the very bottom it will also tell you how many results were pulled matching your search.")
print(f"\n{Fore.GREEN}CATEGORIES are printed in GREEN{Style.RESET_ALL}")
print(f"{Fore.YELLOW}SUBCATEGORIES are printed in YELLOW{Style.RESET_ALL}{Fore.YELLOW}{Style.RESET_ALL}")
print(f"{Fore.RED}ITEMS are printed in RED{Style.RESET_ALL}{Fore.RED}{Style.RESET_ALL}")


count = 0

def search_forge_menu(keyword):
    global count
    count = 0
    results = []
    words = keyword.lower().split()
    categories = {}
    for category, items in ForgeMenu.items():
        category_results = []
        for subcategory, subitems in items.items():
            subcategory_results = []
            for item in subitems:
                if all(word in item.lower().split() for word in words):
                    ratio = 100
                    subcategory_results.append((item, ratio))
                    count += 1
            if subcategory_results:
                category_results.append((subcategory, subcategory_results))
        if category_results:
            categories[category] = category_results
    for category, subcategories in categories.items():
        print(f"\n{Fore.GREEN}{category}{Style.RESET_ALL}")
        for subcategory, subitems in subcategories:
            print(f"\n{Fore.YELLOW}{subcategory}{Style.RESET_ALL}")
            for item, ratio in subitems:
                print(f"{Fore.RED}\u25A0 {item}{Style.RESET_ALL} ({ratio}% match)")



def main():
    global count

    searchItem = input("\nWhat Item would you like to search for?:")
    result = search_forge_menu(searchItem)
    print(f"\n{Fore.LIGHTMAGENTA_EX}{count} RESULTS{Style.RESET_ALL}")

    main()




    
main()






